package com.microservicespringboot;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MicroservicesSpringbootApplicationTests {

	@Test
	void contextLoads() {
	}

}
